<template>
  <div class="logo-container">
    <v-avatar size="60" color="white" elevation="4">
      <v-img
        :src="logoSrc"
        alt="Lạc GO Logo"
        contain
      >
        <template v-slot:placeholder>
          <div class="d-flex align-center justify-center fill-height">
            <v-icon color="primary" size="30">mdi-car</v-icon>
          </div>
        </template>
      </v-img>
    </v-avatar>
  </div>
</template>

<script setup lang="ts">
import logoSrc from '@/assets/logo.svg'
</script>

<style scoped>
.logo-container {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
