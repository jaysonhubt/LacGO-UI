<template>
  <v-app>
    <router-view />
  </v-app>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'

const authStore = useAuthStore()

onMounted(() => {
  // Check if user is already logged in
  authStore.checkAuthStatus()
})
</script>

<style>
html {
  overflow-y: auto !important;
}

.v-application {
  font-family: 'Roboto', sans-serif !important;
}
</style>
