<template>
  <v-container fluid class="forgot-password-container">
    <div class="mountain-background"></div>
    <div class="forgot-password-content">
      <div class="logo-section">
        <LogoComponent />
      </div>
      
      <v-card class="forgot-password-form" elevation="8" rounded="xl">
        <v-card-text class="pa-8">
          <h2 class="text-center mb-6 text-h4 font-weight-bold">Quên mật khẩu</h2>
          <p class="text-center text-medium-emphasis mb-6">
            Nhập email hoặc số điện thoại để nhận mã xác nhận
          </p>
          
          <v-form @submit.prevent="handleForgotPassword" ref="form">
            <v-text-field
              v-model="email"
              label="Email hoặc số điện thoại"
              variant="outlined"
              :rules="emailRules"
              prepend-inner-icon="mdi-account"
              class="mb-4"
              required
            />
            
            <v-btn
              type="submit"
              color="primary"
              size="large"
              block
              class="mb-4"
              :loading="authStore.loading"
              rounded="lg"
            >
              Tiếp tục
            </v-btn>
          </v-form>
          
          <div class="text-center">
            <router-link to="/login" class="text-primary text-decoration-none">
              Quay về đăng nhập
            </router-link>
          </div>
        </v-card-text>
      </v-card>
    </div>
    
    <v-snackbar v-model="showError" color="error" :timeout="3000">
      {{ authStore.error }}
    </v-snackbar>
  </v-container>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useAuthStore } from '@/stores/auth'
import LogoComponent from '@/components/LogoComponent.vue'

const authStore = useAuthStore()
const form = ref()
const email = ref('')

const showError = computed(() => !!authStore.error)

const emailRules = [
  (v: string) => !!v || 'Email hoặc số điện thoại là bắt buộc',
  (v: string) => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    const phonePattern = /^[0-9]{10,11}$/
    return emailPattern.test(v) || phonePattern.test(v) || 'Email hoặc số điện thoại không hợp lệ'
  }
]

const handleForgotPassword = async () => {
  const { valid } = await form.value.validate()
  if (valid) {
    await authStore.forgotPassword(email.value)
  }
}
</script>

<style scoped>
.forgot-password-container {
  height: 100vh;
  position: relative;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.mountain-background {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(180deg, #1B5E20 0%, #2E7D32 50%, #4CAF50 100%);
  background-image: 
    radial-gradient(ellipse at 30% 80%, rgba(255,255,255,0.1) 0%, transparent 50%),
    radial-gradient(ellipse at 70% 70%, rgba(255,255,255,0.1) 0%, transparent 50%),
    radial-gradient(ellipse at 50% 90%, rgba(255,255,255,0.05) 0%, transparent 60%);
}

.forgot-password-content {
  position: relative;
  z-index: 1;
  width: 100%;
  max-width: 400px;
  padding: 20px;
}

.logo-section {
  display: flex;
  justify-content: center;
  margin-bottom: -30px;
  position: relative;
  z-index: 2;
}

.forgot-password-form {
  margin-top: 0;
  padding-top: 40px;
}

@media (max-width: 600px) {
  .forgot-password-content {
    max-width: 350px;
    padding: 16px;
  }
  
  .forgot-password-form .v-card-text {
    padding: 24px !important;
  }
}
</style>
