<template>
  <v-container fluid class="login-container">
    <!-- Gradient Header -->
    <div class="gradient-header">
      <div class="welcome-section">
        <div class="logo-section">
          <LogoComponent />
        </div>
        <div class="welcome-text">
          <h1 class="text-h3 font-weight-bold mb-2">Chào mừng trở lại!</h1>
          <p class="text-h6 mb-0">Đăng nhập để tiếp tục với Lạc GO</p>
        </div>
      </div>
    </div>
    
    <div class="content-wrapper">
      <v-card class="login-form" elevation="2" rounded="xl">
        <v-card-text class="pa-6">
          <h2 class="text-center mb-6 text-h5 font-weight-bold">Đăng nhập tài khoản</h2>
          
          <v-form @submit.prevent="handleLogin" ref="form">
            <v-text-field
              v-model="credentials.email"
              label="📧 Email hoặc số điện thoại"
              variant="outlined"
              :rules="emailRules"
              class="mb-4 custom-input"
              required
              rounded="lg"
            />
            
            <v-text-field
              v-model="credentials.password"
              label="🔒 Mật khẩu"
              variant="outlined"
              :type="showPassword ? 'text' : 'password'"
              :rules="passwordRules"
              :append-inner-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
              @click:append-inner="showPassword = !showPassword"
              class="mb-4 custom-input"
              required
              rounded="lg"
            />
            
            <v-btn
              type="submit"
              class="login-btn mb-4"
              size="large"
              block
              :loading="authStore.loading"
              rounded="xl"
            >
              <v-icon start>mdi-login</v-icon>
              Đăng nhập
            </v-btn>
          </v-form>
          
          <v-divider class="my-4">
            <span class="text-caption text-medium-emphasis px-4">HOẶC</span>
          </v-divider>
          
          <v-btn
            variant="outlined"
            size="large"
            block
            class="mb-3"
            prepend-icon="mdi-google"
            rounded="lg"
          >
            Đăng nhập với Google
          </v-btn>
          
          <v-btn
            variant="outlined"
            size="large"
            block
            class="mb-4"
            prepend-icon="mdi-apple"
            rounded="lg"
          >
            Đăng nhập với Apple
          </v-btn>
          
          <div class="text-center">
            <router-link to="/forgot-password" class="text-primary text-decoration-none">
              Quên mật khẩu?
            </router-link>
          </div>
          
          <div class="text-center mt-3">
            <span class="text-medium-emphasis">Chưa có tài khoản? </span>
            <router-link to="/register" class="text-primary text-decoration-none font-weight-medium">
              Tạo tài khoản
            </router-link>
          </div>
        </v-card-text>
      </v-card>
    </div>
    
    <v-snackbar v-model="showError" color="error" :timeout="3000">
      {{ authStore.error }}
    </v-snackbar>
  </v-container>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useAuthStore } from '@/stores/auth'
import LogoComponent from '@/components/LogoComponent.vue'

const authStore = useAuthStore()
const form = ref()
const showPassword = ref(false)

const credentials = ref({
  email: '',
  password: ''
})

const showError = computed(() => !!authStore.error)

const emailRules = [
  (v: string) => !!v || 'Email hoặc số điện thoại là bắt buộc',
  (v: string) => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    const phonePattern = /^[0-9]{10,11}$/
    return emailPattern.test(v) || phonePattern.test(v) || 'Email hoặc số điện thoại không hợp lệ'
  }
]

const passwordRules = [
  (v: string) => !!v || 'Mật khẩu là bắt buộc',
  (v: string) => v.length >= 6 || 'Mật khẩu phải có ít nhất 6 ký tự'
]

const handleLogin = async () => {
  const { valid } = await form.value.validate()
  if (valid) {
    await authStore.login(credentials.value)
  }
}
</script>

<style scoped>
.login-container {
  padding: 0;
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* Gradient Header */
.gradient-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding-bottom: 40px;
  position: relative;
  overflow: hidden;
}

.gradient-header::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 20"><defs><radialGradient id="a" cx="50%" cy="40%"><stop offset="0%" stop-color="rgba(255,255,255,.1)"/><stop offset="100%" stop-color="rgba(255,255,255,0)"/></radialGradient></defs><rect width="100%" height="100%" fill="url(%23a)"/></svg>');
  opacity: 0.3;
}

.welcome-section {
  padding: 60px 20px 20px;
  position: relative;
  z-index: 1;
}

.welcome-text {
  text-align: center;
  color: white;
}

.logo-section {
  text-align: center;
  margin-bottom: 2rem;
}

/* Content Wrapper */
.content-wrapper {
  padding: 20px;
  margin-top: -20px;
  position: relative;
  z-index: 2;
}

/* Login Form */
.login-form {
  background: linear-gradient(145deg, #ffffff 0%, #f8f9ff 100%);
  border: 1px solid rgba(255, 255, 255, 0.3);
  backdrop-filter: blur(10px);
  max-width: 400px;
  margin: 0 auto;
}

/* Custom Input Styling */
.custom-input .v-field {
  background: rgba(255, 255, 255, 0.9);
  border-radius: 12px;
}

/* Login Button */
.login-btn {
  background: linear-gradient(45deg, #667eea 0%, #764ba2 100%) !important;
  color: white !important;
  font-weight: bold;
  text-transform: none;
  letter-spacing: 0.5px;
}

/* Social Buttons */
.social-btn {
  border: 1px solid rgba(0, 0, 0, 0.12);
  margin-bottom: 8px;
  text-transform: none;
}

/* Links */
.text-primary {
  color: #667eea !important;
  font-weight: 600;
}

/* Mobile Responsive */
@media (max-width: 600px) {
  .content-wrapper {
    padding: 16px;
    margin-top: -16px;
  }
  
  .welcome-section {
    padding: 40px 16px 16px;
  }
  
  .welcome-text h1 {
    font-size: 1.8rem;
  }
  
  .welcome-text p {
    font-size: 1rem;
  }
  
  .login-form .pa-6 {
    padding: 20px !important;
  }
}
</style>
